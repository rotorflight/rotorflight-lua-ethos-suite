

local folder = "yge"


local foundEsc = false
local foundEscDone = false


local apidata = {
    api = {
        [1] = "ESC_PARAMETERS_YGE",
    },
    formdata = {
        labels = {
        },
        fields = {
            {t = "Gov-P", mspapi = 1, apikey="gov_p"},
            {t = "Gov-I", mspapi = 1, apikey="gov_i"},
            {t = "Motor Pole Pairs", mspapi = 1, apikey="motor_pole_pairs"},
            {t = "Main Teeth", mspapi = 1, apikey="main_teeth"},
            {t = "Pinion Teeth" , mspapi = 1, apikey="pinion_teeth"} ,
            {t = "Stick Zero", mspapi = 1, apikey="stick_zero_us"},
            {t = "Stick Range", mspapi = 1, apikey="stick_range_us"},
        }
    }                 
}




local function postLoad()
    rfsuite.app.triggers.closeProgressLoader = true
end

local function onNavMenu(self)
    rfsuite.app.triggers.escToolEnableButtons = true
    rfsuite.app.ui.openPage(pidx, folder, "esc_tools/esc_tool.lua")
end

local function event(widget, category, value, x, y)
    
    if category == 5 or value == 35 then
        rfsuite.app.ui.openPage(pidx, folder, "esc_tools/esc_tool.lua")
        return true
    end

    return false
end

return {
    apidata = apidata,
    eepromWrite = true,
    reboot = false,
    escinfo = escinfo,
    postLoad = postLoad,
    navButtons = {menu = true, save = true, reload = true, tool = false, help = false},
    onNavMenu = onNavMenu,
    event = event,
    pageTitle = "ESC Tools" .. " / " ..  "YGE" .. " / " .. "Other",
    headerLine = rfsuite.escHeaderLineText

}
