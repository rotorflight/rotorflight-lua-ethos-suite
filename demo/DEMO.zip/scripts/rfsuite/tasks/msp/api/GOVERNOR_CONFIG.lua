--[[
 * Copyright (C) Rotorflight Project
 *
 * License GPLv3: https://www.gnu.org/licenses/gpl-3.0.en.html
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 3 as
 * published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * Note. Some icons have been sourced from https://www.flaticon.com/
]] --
local core = assert(rfsuite.compiler.loadfile("tasks/msp/api_core.lua"))()

-- Constants for MSP Commands
local API_NAME = "GOVERNOR_CONFIG" -- API name (must be same as filename)
local MSP_API_CMD_READ = 142 -- Command identifier for MSP Mixer Config Read
local MSP_API_CMD_WRITE = 143 -- Command identifier for saving Mixer Config Settings
local MSP_REBUILD_ON_WRITE = false -- Rebuild the payload on write 

-- define msp structure for reading and writing

local MSP_API_STRUCTURE_READ_DATA

if rfsuite.utils.apiVersionCompare(">=", "12.09") then

    local gov_modeTable ={[0] = "OFF", "EXTERNAL", "ELECTRIC", "NITRO"}
    local throttleTypeTable ={[0] = "NORMAL", "OFF_ON","OFF_IDLE_ON","OFF_IDLE_AUTO_ON"}

    MSP_API_STRUCTURE_READ_DATA = {
        {field = "gov_mode",                        type = "U8",  apiVersion = 12.09, simResponse = {2},    min = 0,  max = #gov_modeTable, table = gov_modeTable, help = "@i18n(api.GOVERNOR_CONFIG.gov_mode)@"},
        {field = "gov_startup_time",                type = "U16", apiVersion = 12.09, simResponse = {200, 0}, min = 0,  max = 600, unit = "s", default = 200, decimals = 1, scale = 10, help = "Time constant for slow startup, in seconds, measuring the time from zero to full headspeed."},
        {field = "gov_spoolup_time",                type = "U16", apiVersion = 12.09, simResponse = {100, 0}, min = 0,  max = 600, unit = "s", default = 100, decimals = 1, scale = 10, help = "Time constant for slow spoolup, in seconds, measuring the time from zero to full headspeed."},
        {field = "gov_tracking_time",               type = "U16", apiVersion = 12.09, simResponse = {20, 0},  min = 0,  max = 100, unit = "s", default = 10,  decimals = 1, scale = 10, help = "Time constant for headspeed changes, in seconds, measuring the time from zero to full headspeed."},
        {field = "gov_recovery_time",               type = "U16", apiVersion = 12.09, simResponse = {20, 0},  min = 0,  max = 100, unit = "s", default = 21,  decimals = 1, scale = 10, help = "Time constant for recovery spoolup, in seconds, measuring the time from zero to full headspeed."},
        {field = "gov_throttle_hold_timeout",       type = "U16", apiVersion = 12.09, simResponse = {50, 0},  min = 0,  max = 250, unit = "s", default = 5,  decimals = 1, scale = 10, help = "@i18n(api.GOVERNOR_CONFIG.gov_throttle_hold_timeout)@"},
        {field = "gov_lost_headspeed_timeout",      type = "U16", apiVersion = 12.09, simResponse = {0, 0}, help = "@i18n(api.GOVERNOR_CONFIG.gov_lost_headspeed_timeout)@"},   -- padding in 12.09
        {field = "gov_autorotation_timeout",        type = "U16", apiVersion = 12.09, simResponse = {0, 0}, help = "@i18n(api.GOVERNOR_CONFIG.gov_autorotation_timeout)@"},   -- padding in 12.09
        {field = "gov_autorotation_bailout_time",   type = "U16", apiVersion = 12.09, simResponse = {0, 0}, help = "@i18n(api.GOVERNOR_CONFIG.gov_autorotation_bailout_time)@"},   -- padding in 12.09
        {field = "gov_autorotation_min_entry_time", type = "U16", apiVersion = 12.09, simResponse = {0, 0}, help = "@i18n(api.GOVERNOR_CONFIG.gov_autorotation_min_entry_time)@"},   -- padding in 12.09
        {field = "gov_handover_throttle",           type = "U8",  apiVersion = 12.09, simResponse = {20},   min = 0, max = 50,  unit = "%", default = 20, help = "Governor activates above this %. Below this the input throttle is passed to the ESC."},
        {field = "gov_pwr_filter",                  type = "U8",  apiVersion = 12.09, simResponse = {20}, unit = "Hz", min = 0, max = 250, default = 20, help = "@i18n(api.GOVERNOR_CONFIG.gov_pwr_filter)@"},
        {field = "gov_rpm_filter",                  type = "U8",  apiVersion = 12.09, simResponse = {20}, unit = "Hz", min = 0, max = 250, default = 20, help = "@i18n(api.GOVERNOR_CONFIG.gov_rpm_filter)@"},
        {field = "gov_tta_filter",                  type = "U8",  apiVersion = 12.09, simResponse = {0}, unit = "Hz", min = 0, max = 250, default = 20, help = "@i18n(api.GOVERNOR_CONFIG.gov_tta_filter)@"},
        {field = "gov_ff_filter",                   type = "U8",  apiVersion = 12.09, simResponse = {10}, unit = "Hz", min = 0, max = 25, default = 10, help = "@i18n(api.GOVERNOR_CONFIG.gov_ff_filter)@"},
        {field = "gov_spoolup_min_throttle",        type = "U8",  apiVersion = 12.09, simResponse = {0}, help = "Minimum throttle to use for slow spoolup, in percent. For electric motors the default is 5%, for nitro this should be set so the clutch starts to engage for a smooth spoolup 10-15%."},      -- padding in 12.09
        {field = "gov_d_filter",                    type = "U8",  apiVersion = 12.09, simResponse = {50}, unit = "Hz", min = 0, max = 250, default = 50, decimals = 1, scale = 10, help = "@i18n(api.GOVERNOR_CONFIG.gov_d_filter)@"},
        {field = "gov_spooldown_time",              type = "U16", apiVersion = 12.09, simResponse = {30, 0}, min = 0,  max = 600, unit = "s", default = 100, decimals = 1, scale = 10, help = "@i18n(api.GOVERNOR_CONFIG.gov_spooldown_time)@"},
        {field = "gov_throttle_type",               type = "U8",  apiVersion = 12.09, simResponse = {0}, min = 0, max = #throttleTypeTable, table = throttleTypeTable, help = "@i18n(api.GOVERNOR_CONFIG.gov_throttle_type)@"},
        {field = "gov_idle_collective",             type = "S8",  apiVersion = 12.09, simResponse = {161}, unit = "%", min = -100, max = 100, default = -95, help = "@i18n(api.GOVERNOR_CONFIG.gov_idle_collective)@"},
        {field = "gov_wot_collective",              type = "S8",  apiVersion = 12.09, simResponse = {246}, unit = "%", min = -100, max = 100, default = -10, help = "@i18n(api.GOVERNOR_CONFIG.gov_wot_collective)@"},
        {field = "governor_idle_throttle",          type = "U8",    apiVersion = 12.09, simResponse = {10},     min = 0,   max = 100,   default = 0,  unit = "%", help = "Idle throttle"},
        {field = "governor_auto_throttle",          type = "U8",    apiVersion = 12.09, simResponse = {10},     min = 0,   max = 100,   default = 0,  unit = "%", help = "Auto throttle"},

    }

else

    local gov_modeTable ={[0] = "OFF", "PASSTHROUGH", "STANDARD", "MODE1", "MODE2"}

    MSP_API_STRUCTURE_READ_DATA = {
        {field = "gov_mode",                        type = "U8",  apiVersion = 12.06, simResponse = {3},    min = 0,  max = #gov_modeTable,   table = gov_modeTable, help = "@i18n(api.GOVERNOR_CONFIG.gov_mode)@"},
        {field = "gov_startup_time",                type = "U16", apiVersion = 12.06, simResponse = {100, 0}, min = 0,  max = 600, unit = "s", default = 200, decimals = 1, scale = 10, help = "Time constant for slow startup, in seconds, measuring the time from zero to full headspeed."},
        {field = "gov_spoolup_time",                type = "U16", apiVersion = 12.06, simResponse = {100, 0}, min = 0,  max = 600, unit = "s", default = 100, decimals = 1, scale = 10, help = "Time constant for slow spoolup, in seconds, measuring the time from zero to full headspeed."},
        {field = "gov_tracking_time",               type = "U16", apiVersion = 12.06, simResponse = {20, 0},  min = 0,  max = 100, unit = "s", default = 10,  decimals = 1, scale = 10, help = "Time constant for headspeed changes, in seconds, measuring the time from zero to full headspeed."},
        {field = "gov_recovery_time",               type = "U16", apiVersion = 12.06, simResponse = {20, 0},  min = 0,  max = 100, unit = "s", default = 21,  decimals = 1, scale = 10, help = "Time constant for recovery spoolup, in seconds, measuring the time from zero to full headspeed."},
        {field = "gov_zero_throttle_timeout",       type = "U16", apiVersion = 12.06, simResponse = {30, 0}, help = "@i18n(api.GOVERNOR_CONFIG.gov_zero_throttle_timeout)@"}, 
        {field = "gov_lost_headspeed_timeout",      type = "U16", apiVersion = 12.06, simResponse = {10, 0}, help = "@i18n(api.GOVERNOR_CONFIG.gov_lost_headspeed_timeout)@"},
        {field = "gov_autorotation_timeout",        type = "U16", apiVersion = 12.06, simResponse = {0, 0}, help = "@i18n(api.GOVERNOR_CONFIG.gov_autorotation_timeout)@"},
        {field = "gov_autorotation_bailout_time",   type = "U16", apiVersion = 12.06, simResponse = {0, 0}, help = "@i18n(api.GOVERNOR_CONFIG.gov_autorotation_bailout_time)@"},
        {field = "gov_autorotation_min_entry_time", type = "U16", apiVersion = 12.06, simResponse = {50, 0}, help = "@i18n(api.GOVERNOR_CONFIG.gov_autorotation_min_entry_time)@"},
        {field = "gov_handover_throttle",           type = "U8",  apiVersion = 12.06, simResponse = {10},   min = 10, max = 50,  unit = "%", default = 20, help = "Governor activates above this %. Below this the input throttle is passed to the ESC."},
        {field = "gov_pwr_filter",                  type = "U8",  apiVersion = 12.06, simResponse = {5}, help = "@i18n(api.GOVERNOR_CONFIG.gov_pwr_filter)@"},
        {field = "gov_rpm_filter",                  type = "U8",  apiVersion = 12.06, simResponse = {10}, help = "@i18n(api.GOVERNOR_CONFIG.gov_rpm_filter)@"},
        {field = "gov_tta_filter",                  type = "U8",  apiVersion = 12.06, simResponse = {0}, help = "@i18n(api.GOVERNOR_CONFIG.gov_tta_filter)@"},
        {field = "gov_ff_filter",                   type = "U8",  apiVersion = 12.06, simResponse = {10}, help = "@i18n(api.GOVERNOR_CONFIG.gov_ff_filter)@"},
        {field = "gov_spoolup_min_throttle",        type = "U8",  apiVersion = 12.08, simResponse = {5},    min = 0,  max = 50,  unit = "%", default = 0, help = "Minimum throttle to use for slow spoolup, in percent. For electric motors the default is 5%, for nitro this should be set so the clutch starts to engage for a smooth spoolup 10-15%."},
    }
end

-- Process structure in one pass
local MSP_API_STRUCTURE_READ, MSP_MIN_BYTES, MSP_API_SIMULATOR_RESPONSE =
    core.prepareStructureData(MSP_API_STRUCTURE_READ_DATA)

-- set read structure
local MSP_API_STRUCTURE_WRITE = MSP_API_STRUCTURE_READ

-- Variable to store parsed MSP data
local mspData = nil
local mspWriteComplete = false
local payloadData = {}
local defaultData = {}

-- Create a new instance
local handlers = core.createHandlers()

-- Variables to store optional the UUID and timeout for payload
local MSP_API_UUID
local MSP_API_MSG_TIMEOUT

-- Track write completion without closures
local lastWriteUUID = nil
-- weak keys/values so finished entries don't pin memory
local writeDoneRegistry = setmetatable({}, { __mode = "kv" })


local function processReplyStaticRead(self, buf)
  core.parseMSPData(API_NAME, buf, self.structure, nil, nil, function(result)
    mspData = result
    if #buf >= (self.minBytes or 0) then
      local getComplete = self.getCompleteHandler
      if getComplete then
        local complete = getComplete()
        if complete then complete(self, buf) end
      end
    end
  end)
end

local function processReplyStaticWrite(self, buf)
  mspWriteComplete = true
  -- mark this UUID as completed (no module locals touched)
  if self.uuid then writeDoneRegistry[self.uuid] = true end

  local getComplete = self.getCompleteHandler
  if getComplete then
    local complete = getComplete()
    if complete then complete(self, buf) end
  end
end

local function errorHandlerStatic(self, buf)
  local getError = self.getErrorHandler
  if getError then
    local err = getError()
    if err then err(self, buf) end
  end
end

-- Function to initiate MSP read operation
local function read()
  if MSP_API_CMD_READ == nil then
    rfsuite.utils.log("No value set for MSP_API_CMD_READ", "debug")
    return
  end

  local message = {
    command           = MSP_API_CMD_READ,
    structure         = MSP_API_STRUCTURE_READ,   -- add this
    minBytes          = MSP_MIN_BYTES,            -- and this
    processReply      = processReplyStaticRead,
    errorHandler      = errorHandlerStatic,
    simulatorResponse = MSP_API_SIMULATOR_RESPONSE,
    uuid              = MSP_API_UUID,
    timeout           = MSP_API_MSG_TIMEOUT,
    getCompleteHandler = handlers.getCompleteHandler,
    getErrorHandler    = handlers.getErrorHandler,
    -- optional: place to stash parsed data if you want it here:
    mspData           = nil,
  }
  rfsuite.tasks.msp.mspQueue:add(message)
end

local function write(suppliedPayload)
  if MSP_API_CMD_WRITE == nil then
    rfsuite.utils.log("No value set for MSP_API_CMD_WRITE", "debug")
    return
  end

  -- Build payload eagerly (no capture)
  local payload = suppliedPayload or
    core.buildWritePayload(API_NAME, payloadData, MSP_API_STRUCTURE_WRITE, MSP_REBUILD_ON_WRITE)

  -- Choose a UUID for this write; if you already set MSP_API_UUID elsewhere, we’ll reuse it
  local uuid = MSP_API_UUID or rfsuite.utils and rfsuite.utils.uuid and rfsuite.utils.uuid() or tostring(os.clock())
  lastWriteUUID = uuid  -- track the most recent write without a closure

  local message = {
    command            = MSP_API_CMD_WRITE,
    payload            = payload,
    processReply       = processReplyStaticWrite, -- static, no upvalues
    errorHandler       = errorHandlerStatic,      -- static, no upvalues
    simulatorResponse  = {},

    uuid               = uuid,
    timeout            = MSP_API_MSG_TIMEOUT,

    -- provide handler getters so static callbacks can resolve at runtime
    getCompleteHandler = handlers.getCompleteHandler,
    getErrorHandler    = handlers.getErrorHandler,
  }

  rfsuite.tasks.msp.mspQueue:add(message)
end

-- Function to get the value of a specific field from MSP data
local function readValue(fieldName)
    if mspData and mspData['parsed'][fieldName] ~= nil then return mspData['parsed'][fieldName] end
    return nil
end

-- Function to set a value dynamically
local function setValue(fieldName, value)
    payloadData[fieldName] = value
end

-- Function to check if the read operation is complete
local function readComplete()
    return mspData ~= nil and #mspData['buffer'] >= MSP_MIN_BYTES
end

-- Function to check if the write operation is complete
local function writeComplete()
    return mspWriteComplete
end

-- Function to reset the write completion status
local function resetWriteStatus()
    mspWriteComplete = false
end

-- Function to return the parsed MSP data
local function data()
    return mspData
end

-- set the UUID for the payload
local function setUUID(uuid)
    MSP_API_UUID = uuid
end

-- set the timeout for the payload
local function setTimeout(timeout)
    MSP_API_MSG_TIMEOUT = timeout
end

-- Return the module's API functions
return {
    read = read,
    write = write,
    readComplete = readComplete,
    writeComplete = writeComplete,
    readValue = readValue,
    setValue = setValue,
    resetWriteStatus = resetWriteStatus,
    setCompleteHandler = handlers.setCompleteHandler,
    setErrorHandler = handlers.setErrorHandler,
    data = data,
    setUUID = setUUID,
    setTimeout = setTimeout
}
