return {
  [1] = {
    varname = "dashboard",
    key = "ofs3dsh",
    name = "OFS3 Dashboard",
    script = "dashboard.lua",
    folder = "dashboard",
  },
}
