local settings = {}
local enableWakeup = false

local function openPage(pageIdx, title, script)
    enableWakeup = true
    ofs3.app.triggers.closeProgressLoader = true
    form.clear()

    ofs3.app.lastIdx    = pageIdx
    ofs3.app.lastTitle  = title
    ofs3.app.lastScript = script

    ofs3.app.ui.fieldHeader(
        "Settings" .. " / " .. "Development"
    )
    ofs3.session.formLineCnt = 0

    local formFieldCount = 0

    settings = ofs3.preferences.developer

formFieldCount = formFieldCount + 1
    ofs3.session.formLineCnt = ofs3.session.formLineCnt + 1
    ofs3.app.formLines[ofs3.session.formLineCnt] = form.addLine("Developer Tools")
    ofs3.app.formFields[formFieldCount] = form.addBooleanField(ofs3.app.formLines[ofs3.session.formLineCnt], 
                                                        nil, 
                                                        function() 
                                                            if ofs3.preferences and ofs3.preferences.developer then
                                                                return settings['devtools'] 
                                                            end
                                                        end, 
                                                        function(newValue) 
                                                            if ofs3.preferences and ofs3.preferences.developer then
                                                                settings.devtools = newValue
                                                            end    
                                                        end)    


    formFieldCount = formFieldCount + 1
    ofs3.session.formLineCnt = ofs3.session.formLineCnt + 1
    ofs3.app.formLines[ofs3.session.formLineCnt] = form.addLine("Compilation")
    ofs3.app.formFields[formFieldCount] = form.addBooleanField(ofs3.app.formLines[ofs3.session.formLineCnt], 
                                                        nil, 
                                                        function() 
                                                            if ofs3.preferences and ofs3.preferences.developer then
                                                                return settings['compile'] 
                                                            end
                                                        end, 
                                                        function(newValue) 
                                                            if ofs3.preferences and ofs3.preferences.developer then
                                                                settings.compile = newValue
                                                            end    
                                                        end)                                                        



    local logpanel = form.addExpansionPanel("Logging")
    logpanel:open(false) 

    formFieldCount = formFieldCount + 1
    ofs3.session.formLineCnt = ofs3.session.formLineCnt + 1
    ofs3.app.formLines[ofs3.session.formLineCnt] = logpanel:addLine("Log location")
    ofs3.app.formFields[formFieldCount] = form.addChoiceField(ofs3.app.formLines[ofs3.session.formLineCnt], nil, 
                                                        {{"CONSOLE", 0}, {"CONSOLE & FILE", 1}}, 
                                                        function() 
                                                            if ofs3.preferences and ofs3.preferences.developer then
                                                                if ofs3.preferences.developer.logtofile  == false then
                                                                    return 0
                                                                else
                                                                    return 1
                                                                end   
                                                            end
                                                        end, 
                                                        function(newValue) 
                                                            if ofs3.preferences and ofs3.preferences.developer then
                                                                local value
                                                                if newValue == 0 then
                                                                    value = false
                                                                else    
                                                                    value = true
                                                                end    
                                                                settings.logtofile = value
                                                            end    
                                                        end) 

    formFieldCount = formFieldCount + 1
    ofs3.session.formLineCnt = ofs3.session.formLineCnt + 1
    ofs3.app.formLines[ofs3.session.formLineCnt] = logpanel:addLine("Log level")
    ofs3.app.formFields[formFieldCount] = form.addChoiceField(ofs3.app.formLines[ofs3.session.formLineCnt], nil, 
                                                        {{"OFF", 0}, {"INFO", 1}, {"DEBUG", 2}}, 
                                                        function() 
                                                            if ofs3.preferences and ofs3.preferences.developer then
                                                                if settings['loglevel']  == "off" then
                                                                    return 0
                                                                elseif settings['loglevel']  == "info" then
                                                                    return 1
                                                                else
                                                                    return 2
                                                                end   
                                                            end
                                                        end, 
                                                        function(newValue) 
                                                            if ofs3.preferences and ofs3.preferences.developer then
                                                                local value
                                                                if newValue == 0 then
                                                                    value = "off"
                                                                elseif newValue == 1 then
                                                                    value = "info"
                                                                else
                                                                    value = "debug"
                                                                end    
                                                                settings['loglevel'] = value 
                                                            end    
                                                        end) 
 

    formFieldCount = formFieldCount + 1
    ofs3.session.formLineCnt = ofs3.session.formLineCnt + 1
    ofs3.app.formLines[ofs3.session.formLineCnt] = logpanel:addLine("Log memory usage")
    ofs3.app.formFields[formFieldCount] = form.addBooleanField(ofs3.app.formLines[ofs3.session.formLineCnt], 
                                                        nil, 
                                                        function() 
                                                            if ofs3.preferences and ofs3.preferences.developer then
                                                                return settings['memstats'] 
                                                            end
                                                        end, 
                                                        function(newValue) 
                                                            if ofs3.preferences and ofs3.preferences.developer then
                                                                settings.memstats = newValue
                                                            end    
                                                        end)  

    
end

local function onNavMenu()
    ofs3.app.ui.progressDisplay()
    ofs3.app.ui.openPage(
        pageIdx,
        "Settings",
        "settings/settings.lua"
    )
end

local function onSaveMenu()
    local buttons = {
        {
            label  = "                OK                ",
            action = function()
                local msg = "Save current page to radio?"
                ofs3.app.ui.progressDisplaySave(msg:gsub("%?$", "."))
                for key, value in pairs(settings) do
                    ofs3.preferences.developer[key] = value
                end
                ofs3.ini.save_ini_file(
                    "SCRIPTS:/" .. ofs3.config.preferences .. "/preferences.ini",
                    ofs3.preferences
                )
                
                ofs3.app.triggers.closeSave = true
                return true
            end,
        },
        {
            label  = "CANCEL",
            action = function()
                return true
            end,
        },
    }

    form.openDialog({
        width   = nil,
        title   = "Save settings",
        message = "Save current page to radio?",
        buttons = buttons,
        wakeup  = function() end,
        paint   = function() end,
        options = TEXT_LEFT,
    })
end

local function event(widget, category, value, x, y)
    -- if close event detected go to section home page
    if category == EVT_CLOSE and value == 0 or value == 35 then
        ofs3.app.ui.openPage(
            pageIdx,
            "Settings",
            "settings/settings.lua"
        )
        return true
    end
end

return {
    event      = event,
    openPage   = openPage,
    wakeup     = wakeup,
    onNavMenu  = onNavMenu,
    onSaveMenu = onSaveMenu,
    navButtons = {
        menu   = true,
        save   = true,
        reload = false,
        tool   = false,
        help   = false,
    },
    API = {},
}
