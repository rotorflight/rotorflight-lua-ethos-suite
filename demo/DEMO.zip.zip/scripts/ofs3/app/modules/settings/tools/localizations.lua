local settings = {}
local enableWakeup = false

local function openPage(pageIdx, title, script)
    enableWakeup = true
    ofs3.app.triggers.closeProgressLoader = true
    form.clear()

    ofs3.app.lastIdx    = pageIdx
    ofs3.app.lastTitle  = title
    ofs3.app.lastScript = script

    ofs3.app.ui.fieldHeader(
        "Settings" .. " / " .. "Dashboard" .. " / " .. "Localization"
    )
    ofs3.session.formLineCnt = 0

    local formFieldCount = 0

    settings = ofs3.preferences.localizations

    formFieldCount = formFieldCount + 1
    ofs3.session.formLineCnt = ofs3.session.formLineCnt + 1
    ofs3.app.formLines[ofs3.session.formLineCnt] = form.addLine("Temperature Unit")
    ofs3.app.formFields[formFieldCount] = form.addChoiceField(ofs3.app.formLines[ofs3.session.formLineCnt], nil, 
                                                        {{"Celsius", 0}, {"Fahrenheit", 1}}, 
                                                        function() 
                                                            if ofs3.preferences and ofs3.preferences.localizations then
                                                                return settings.temperature_unit or 0
                                                            end
                                                        end, 
                                                        function(newValue) 
                                                            if ofs3.preferences and ofs3.preferences.localizations then
                                                                settings.temperature_unit = newValue
                                                            end    
                                                        end) 
            
    formFieldCount = formFieldCount + 1
    ofs3.session.formLineCnt = ofs3.session.formLineCnt + 1
    ofs3.app.formLines[ofs3.session.formLineCnt] = form.addLine("Altitude Unit")
    ofs3.app.formFields[formFieldCount] = form.addChoiceField(ofs3.app.formLines[ofs3.session.formLineCnt], nil, 
                                                        {{"Meters", 0}, {"Feet", 1}}, 
                                                        function() 
                                                            if ofs3.preferences and ofs3.preferences.localizations then
                                                                return settings.altitude_unit or 0
                                                            end
                                                        end, 
                                                        function(newValue) 
                                                            if ofs3.preferences and ofs3.preferences.localizations then
                                                                settings.altitude_unit = newValue
                                                            end    
                                                        end) 
              
                                                  
end

local function onNavMenu()
    ofs3.app.ui.progressDisplay()
        ofs3.app.ui.openPage(
            pageIdx,
            "Settings",
            "settings/settings.lua"
        )
        return true
end

local function onSaveMenu()
    local buttons = {
        {
            label  = "                OK                ",
            action = function()
                local msg = "Save current page to radio?"
                ofs3.app.ui.progressDisplaySave(msg:gsub("%?$", "."))
                for key, value in pairs(settings) do
                    ofs3.preferences.dashboard[key] = value
                end
                ofs3.ini.save_ini_file(
                    "SCRIPTS:/" .. ofs3.config.preferences .. "/preferences.ini",
                    ofs3.preferences
                )
                -- update dashboard theme
                ofs3.widgets.dashboard.reload_themes()
                -- close save progress
                ofs3.app.triggers.closeSave = true
                return true
            end,
        },
        {
            label  = "CANCEL",
            action = function()
                return true
            end,
        },
    }

    form.openDialog({
        width   = nil,
        title   = "Save settings",
        message = "Save current page to radio?",
        buttons = buttons,
        wakeup  = function() end,
        paint   = function() end,
        options = TEXT_LEFT,
    })
end

local function event(widget, category, value, x, y)
    -- if close event detected go to section home page
    if category == EVT_CLOSE and value == 0 or value == 35 then
        ofs3.app.ui.openPage(
            pageIdx,
            "Settings",
            "settings/settings.lua"
        )
        return true
    end
end

return {
    event      = event,
    openPage   = openPage,
    wakeup     = wakeup,
    onNavMenu  = onNavMenu,
    onSaveMenu = onSaveMenu,
    navButtons = {
        menu   = true,
        save   = true,
        reload = false,
        tool   = false,
        help   = false,
    },
    API = {},
}
