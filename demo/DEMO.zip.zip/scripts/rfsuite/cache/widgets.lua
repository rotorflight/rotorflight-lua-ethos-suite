return {
  [1] = {
    folder = "dashboard",
    script = "dashboard.lua",
    name = "Rotorflight Dashboard",
    varname = "dashboard",
    key = "rf2sdh",
  },
  [2] = {
    folder = "toolbox",
    script = "toolbox.lua",
    name = "Rotorflight Toolbox",
    varname = "rftlbx",
    key = "rftlbx",
  },
}
