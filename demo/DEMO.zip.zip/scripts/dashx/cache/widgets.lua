return {
  [1] = {
    key = "dshxdsh",
    name = "DashX",
    folder = "dashboard",
    script = "dashboard.lua",
    varname = "dashboard",
  },
}
