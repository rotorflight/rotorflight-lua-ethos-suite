local settings = {}
local settings_model = {}

local themeList = dashx.widgets.dashboard.listThemes() 
local formattedThemes = {}
local formattedThemesModel = {}

local enableWakeup = false
local prevConnectedState = nil

--- Generates formatted lists of available themes and their models.
-- Iterates over the global `themeList` and populates two tables:
-- `formattedThemes` with theme names and indices, and
-- `formattedThemesModel` with a disabled option followed by theme names and indices.
-- Assumes `themeList`, `formattedThemes`, `formattedThemesModel`, and `dashx.i18n` are defined in the surrounding scope.
local function generateThemeList()

    -- setup environment
    settings = dashx.preferences.dashboard

    if dashx.session.modelPreferences then
        settings_model = dashx.session.modelPreferences.dashboard
    else
        settings_model = {}
    end

    -- build global table
    for i, theme in ipairs(themeList) do
        table.insert(formattedThemes, { theme.name, theme.idx })
    end

    -- build model table
    table.insert(formattedThemesModel, { "Disabled", 0 })
    for i, theme in ipairs(themeList) do
        table.insert(formattedThemesModel, { theme.name, theme.idx })
    end   
end

local function openPage(pageIdx, title, script)
    enableWakeup = true
    dashx.app.triggers.closeProgressLoader = true
    form.clear()

    dashx.app.lastIdx    = pageIdx
    dashx.app.lastTitle  = title
    dashx.app.lastScript = script

    dashx.app.ui.fieldHeader(
        "Settings" .. " / " .. "Dashboard" .. " / " .. "Theme"
    )
    dashx.app.formLineCnt = 0

    local formFieldCount = 0

    -- generate the initial list
    generateThemeList()

    -- ===========================================================================
    -- create global theme selection panel
    -- ===========================================================================
    local global_panel = form.addExpansionPanel("Default theme for all models")
    global_panel:open(true) 

    -- preflight theme selection
    formFieldCount = formFieldCount + 1
    dashx.app.formLineCnt = dashx.app.formLineCnt + 1
    dashx.app.formLines[dashx.app.formLineCnt] = global_panel:addLine("Preflight Theme")
            
    dashx.app.formFields[formFieldCount] = form.addChoiceField(dashx.app.formLines[dashx.app.formLineCnt], nil, 
                                                        formattedThemes, 
                                                        function()
                                                            if dashx.preferences and dashx.preferences.dashboard then
                                                                local folderName = settings.theme_preflight
                                                                for _, theme in ipairs(themeList) do
                                                                    if (theme.source .. "/" .. theme.folder) == folderName then
                                                                        return theme.idx
                                                                    end
                                                                end
                                                            end
                                                            return nil
                                                        end, 
                                                        function(newValue) 
                                                            if dashx.preferences and dashx.preferences.dashboard then
                                                                local theme = themeList[newValue]
                                                                if theme then
                                                                    settings.theme_preflight = theme.source .. "/" .. theme.folder
                                                                end
                                                            end
                                                        end)     

    -- inflight theme selection                                                          
    formFieldCount = formFieldCount + 1
    dashx.app.formLineCnt = dashx.app.formLineCnt + 1
    dashx.app.formLines[dashx.app.formLineCnt] = global_panel:addLine("Inflight Theme")
                              
    dashx.app.formFields[formFieldCount] = form.addChoiceField(dashx.app.formLines[dashx.app.formLineCnt], nil, 
                                                        formattedThemes, 
                                                        function()
                                                            if dashx.preferences and dashx.preferences.dashboard then
                                                                local folderName = settings.theme_inflight
                                                                for _, theme in ipairs(themeList) do
                                                                    if (theme.source .. "/" .. theme.folder) == folderName then
                                                                        return theme.idx
                                                                    end
                                                                end
                                                            end
                                                            return nil
                                                        end, 
                                                        function(newValue) 
                                                            if dashx.preferences and dashx.preferences.dashboard then
                                                                local theme = themeList[newValue]
                                                                if theme then
                                                                    settings.theme_inflight = theme.source .. "/" .. theme.folder
                                                                end
                                                            end
                                                        end)                                                             

                                                        
     -- postflight theme selection                                                            
    formFieldCount = formFieldCount + 1
    dashx.app.formLineCnt = dashx.app.formLineCnt + 1
    dashx.app.formLines[dashx.app.formLineCnt] = global_panel:addLine("Postflight Theme")
                                    
    dashx.app.formFields[formFieldCount] = form.addChoiceField(dashx.app.formLines[dashx.app.formLineCnt], nil, 
                                                        formattedThemes, 
                                                        function()
                                                            if dashx.preferences and dashx.preferences.dashboard then
                                                                local folderName = settings.theme_postflight
                                                                for _, theme in ipairs(themeList) do
                                                                    if (theme.source .. "/" .. theme.folder) == folderName then
                                                                        return theme.idx
                                                                    end
                                                                end
                                                            end
                                                            return nil
                                                        end, 
                                                        function(newValue) 
                                                            if dashx.preferences and dashx.preferences.dashboard then
                                                                local theme = themeList[newValue]
                                                                if theme then
                                                                    settings.theme_postflight = theme.source .. "/" .. theme.folder
                                                                end
                                                            end
                                                        end)      

   -- ===========================================================================
    -- create model theme selection panel
    -- ===========================================================================
    local model_panel = form.addExpansionPanel("Optional theme for this model")
    model_panel:open(false) 


    -- preflight theme selection
    formFieldCount = formFieldCount + 1
    dashx.app.formLineCnt = dashx.app.formLineCnt + 1
    dashx.app.formLines[dashx.app.formLineCnt] = model_panel:addLine("Preflight Theme")
            
    dashx.app.formFields[formFieldCount] = form.addChoiceField(dashx.app.formLines[dashx.app.formLineCnt], nil, 
                                                        formattedThemesModel, 
                                                        function()
                                                            if dashx.session.modelPreferences and dashx.session.modelPreferences then
                                                                local folderName = settings_model.theme_preflight
                                                                for _, theme in ipairs(themeList) do
                                                                    if (theme.source .. "/" .. theme.folder) == folderName then
                                                                        return theme.idx
                                                                    end
                                                                end
                                                            end
                                                            return nil
                                                        end, 
                                                        function(newValue) 
                                                            if dashx.session.modelPreferences and dashx.session.modelPreferences then
                                                                local theme = themeList[newValue]
                                                                if theme then
                                                                    settings_model.theme_preflight = theme.source .. "/" .. theme.folder
                                                                else
                                                                    settings_model.theme_preflight = "nil"    
                                                                end
                                                            end
                                                        end) 
    dashx.app.formFields[formFieldCount]:enable(false)                                                        

    -- inflight theme selection                                                          
    formFieldCount = formFieldCount + 1
    dashx.app.formLineCnt = dashx.app.formLineCnt + 1
    dashx.app.formLines[dashx.app.formLineCnt] = model_panel:addLine("Inflight Theme")
                              
    dashx.app.formFields[formFieldCount] = form.addChoiceField(dashx.app.formLines[dashx.app.formLineCnt], nil, 
                                                        formattedThemesModel, 
                                                        function()
                                                            if dashx.session.modelPreferences and dashx.session.modelPreferences then
                                                                local folderName = settings_model.theme_inflight
                                                                for _, theme in ipairs(themeList) do
                                                                    if (theme.source .. "/" .. theme.folder) == folderName then
                                                                        return theme.idx
                                                                    end
                                                                end
                                                            end
                                                            return nil
                                                        end, 
                                                        function(newValue) 
                                                            if dashx.session.modelPreferences and dashx.session.modelPreferences then
                                                                local theme = themeList[newValue]
                                                                if theme then
                                                                    settings_model.theme_inflight = theme.source .. "/" .. theme.folder
                                                                else
                                                                    settings_model.theme_inflight = "nil"    
                                                                end
                                                            end
                                                        end)                                                             
    dashx.app.formFields[formFieldCount]:enable(false)  
                                                        
     -- postflight theme selection                                                            
    formFieldCount = formFieldCount + 1
    dashx.app.formLineCnt = dashx.app.formLineCnt + 1
    dashx.app.formLines[dashx.app.formLineCnt] = model_panel:addLine("Postflight Theme")
                                    
    dashx.app.formFields[formFieldCount] = form.addChoiceField(dashx.app.formLines[dashx.app.formLineCnt], nil, 
                                                        formattedThemesModel, 
                                                        function()
                                                            if dashx.session.modelPreferences and dashx.session.modelPreferences then
                                                                local folderName = settings_model.theme_postflight
                                                                for _, theme in ipairs(themeList) do
                                                                    if (theme.source .. "/" .. theme.folder) == folderName then
                                                                        return theme.idx
                                                                    end
                                                                end
                                                            end
                                                            return nil
                                                        end, 
                                                        function(newValue) 
                                                            if dashx.preferences and dashx.preferences.dashboard then
                                                                local theme = themeList[newValue]
                                                                if theme then
                                                                    settings_model.theme_postflight = theme.source .. "/" .. theme.folder
                                                                else
                                                                    settings_model.theme_postflight = "nil"    
                                                                end
                                                            end
                                                        end)      
    dashx.app.formFields[formFieldCount]:enable(false)  
                                                  
end

local function onNavMenu()
    dashx.app.ui.progressDisplay(nil,nil,true)
        dashx.app.ui.openPage(
            pageIdx,
            "Dashboard",
            "settings/tools/dashboard.lua"
        )
        return true
end

local function onSaveMenu()
    local buttons = {
        {
            label  = "                OK                ",
            action = function()
                local msg = "Save current page to radio?"
                dashx.app.ui.progressDisplaySave(msg:gsub("%?$", "."))

                -- save global dashboard settings
                for key, value in pairs(settings) do
                    dashx.preferences.dashboard[key] = value
                end
                dashx.ini.save_ini_file(
                    "SCRIPTS:/" .. dashx.config.preferences .. "/preferences.ini",
                    dashx.preferences
                )

                -- save model dashboard settings
                if dashx.session.isConnected and dashx.session.mcu_id and dashx.session.modelPreferencesFile then
                    for key, value in pairs(settings_model) do
                        dashx.session.modelPreferences.dashboard[key] = value
                    end
                    dashx.ini.save_ini_file(
                        dashx.session.modelPreferencesFile,
                        dashx.session.modelPreferences
                    )
                end    
               

                -- update dashboard theme
                dashx.widgets.dashboard.reload_themes(true) -- send true to force full reload
                -- close save progress
                dashx.app.triggers.closeSave = true
                return true
            end,
        },
        {
            label  = "CANCEL",
            action = function()
                return true
            end,
        },
    }

    form.openDialog({
        width   = nil,
        title   = "Save settings",
        message = "Save current page to radio?",
        buttons = buttons,
        wakeup  = function() end,
        paint   = function() end,
        options = TEXT_LEFT,
    })
end

local function event(widget, category, value, x, y)
    -- if close event detected go to section home page
    if category == EVT_CLOSE and value == 0 or value == 35 then
        dashx.app.ui.openPage(
            pageIdx,
            "Dashboard",
            "settings/tools/dashboard.lua"
        )
        return true
    end
end

local function wakeup()
    if not enableWakeup then
        return
    end

    -- current combined state: true only if both are truthy
    local currState = (dashx.session.isConnected and dashx.session.mcu_id) and true or false

    -- only update if state has changed
    if currState ~= prevConnectedState then

        -- if we're now connected, you can do any repopulation here
        if currState then
                generateThemeList()
                for i = 4, 6 do
                    dashx.app.formFields[i]:values(formattedThemesModel)
                end               
        end

        -- toggle all three fields together
        for i = 4, 6 do
            dashx.app.formFields[i]:enable(currState)
        end

        -- remember for next time
        prevConnectedState = currState
    end
end

return {
    event      = event,
    openPage   = openPage,
    wakeup     = wakeup,
    onNavMenu  = onNavMenu,
    onSaveMenu = onSaveMenu,
    navButtons = {
        menu   = true,
        save   = true,
        reload = false,
        tool   = false,
        help   = false,
    },
    API = {},
}
