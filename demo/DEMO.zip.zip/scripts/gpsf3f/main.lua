-- GPS virtual course for F3F script for Ethos
-- https://rc-soar.com/ethos/scripts/gpsf3f/
-- Copyright (c) Michael Shellim 2025 all rights reserved.

local version = "1.0"
local main  = {} -- this module 

-- Controls logging of sensor data. If enabled, it's recommended to disable Ethos logging.
local isLoggingEnabled = false                -- set true to enable logging. 

main.inSim  = system.getVersion().simulation -- running in simulator
main.isDemoMode = true                       -- simulate GPS sensor using sticks
main.soundDir = "sounds/"                     -- look for sounds in voice 1 folder

-- Compile and load modules in dependency order.
local interval = loadfile ("interval.lua")()
local status   = loadfile ("status.lua")()
local logging  = loadfile ("logging.lua")(main)
local sensor   = loadfile ("sensor.lua")(main, logging)
local graph    = loadfile ("graph.lua")()
local switch   = loadfile ("switch.lua")()
local config   = loadfile ("config.lua")()
local course   = loadfile ("course.lua")(sensor, config, graph)
local timer    = loadfile ("timer.lua")()
local f3f      = loadfile ("f3f.lua")(main, course, timer, switch, status, config)
local form     = loadfile ("form.lua")(interval, config, sensor, course, f3f, logging)

local initDisplay -- forward declaration

-- called by the o/s to create a widget instance
-- @return widget table
local function create ()
    print("+++ create()")
    interval.init()
    sensor.init()
    f3f.init()
    if isLoggingEnabled then logging.start()  end
    return config.Init() -- widget table with default settings
end

-- background wakeup function
--  &param widget
local function wakeup(widget)
    interval.update()
    f3f.wakeup(widget)
    lcd.invalidate()  -- force a repaint
end

-- Runs periodically when widget is visible
--  @param widget
local function paint(widget)
    -- print("+++ paint()")
    initDisplay()       -- initialise display regions 
    form.show(widget)   -- display form
    course.show(widget) -- display course
    status.show()       -- display status line
end

-- Allocates size and position for form, status and graphics
function initDisplay ()
    -- Get window area
    local w, h = lcd.getWindowSize()

    -- apply padding
    local padding = 10 -- arbitrary, might need tweaking
    local x0 = padding
    local y0 = padding
    w = w - 2*padding
    h = h - 2*padding

    -- intialise the three regions of the screen (form, status, graphics)
    local htForm = form.init(x0, y0, w)                         -- at top of pane
    local htStatus = status.init(x0, y0, w, h, version)         -- at bottom of pane
    graph.init (x0, (y0 + htForm), w, (h - htForm - htStatus) ) -- between form and status
end

local function init()
  system.registerWidget({
    key="gpsf3f",
    create=create,
    configure=config.configure,
    name= "GPS F3F",
    title=false,
    paint=paint,
    wakeup=wakeup,
    read=config.read,
    write=config.write,
    })
end

return {init=init}
