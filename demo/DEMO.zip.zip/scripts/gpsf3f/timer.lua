-- GPS virtual course for F3F script for Ethos
-- https://rc-soar.com/ethos/scripts/gpsf3f/
-- Copyright (c) Michael Shellim 2025 all rights reserved.

-- Countdown timer module
local timer = {}

local tCountdown    -- countdown duration (seconds)
local t0            -- base time
local t1            -- next threshold

function timer.start(tC)
    tCountdown = tC
    t0 = os.clock()
    t1 = t0
end

-- Function to poll the timer.
--  @return: ticks remaining (secs) or nil
function timer.poll()
    local now = os.clock()
    if now > t1 then
        local wholeSecondsElapsed = math.floor (now - t0)
        t1 = t0 + wholeSecondsElapsed + 1
        return tCountdown - wholeSecondsElapsed
    end
end

return timer
