-- GPS virtual course for F3F script for Ethos
-- https://rc-soar.com/ethos/scripts/gpsf3f/
-- Copyright (c) Michael Shellim 2025 all rights reserved.

local intervalTimer = {}
local t0
local ema
local previousEma
local ALPHA = 0.1

function intervalTimer.init ()
    t0 = nil
    previousEma = nil
    ema = nil
end

function intervalTimer.update ()
    local now = os.clock()
    if t0 ~= nil then
        local currentValue = now - t0
        if previousEma == nil then
            ema = currentValue  -- First value becomes the initial EMA
        else
            ema = ALPHA * currentValue + (1 - ALPHA) * previousEma
        end
        previousEma = ema
    end
    t0 = now
end

function intervalTimer.getFrequency ()
    if ema and ema > 0 then
        return math.floor (1/ema  + 0.5) -- round
    else
        return nil
    end
end


return intervalTimer