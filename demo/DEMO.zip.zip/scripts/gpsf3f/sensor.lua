-- GPS virtual course for F3F script for Ethos
-- https://rc-soar.com/ethos/scripts/gpsf3f/
-- Copyright (c) Michael Shellim 2025 all rights reserved.

-- Sensor module

local main, logging = ...       -- handle to main module passed in loadScript
local sensor = {}               -- this module's data

local lastPktStatus             -- last packet status
local lastLat, lastLon          -- cached lat/lon1. Used to detect changes and connection loss
local srcGPSLat,  srcGPSLon     -- telemetry sources
local srcSats                   
local fmtLatLon = "%-16.11f"    -- format for logging lat/lon values

function sensor.init ()
    srcSats = nil
    srcGPSLat = nil
    srcGPSLon = nil
end

local function discoverSensors()
    srcSats = system.getSource ("Sats")
    srcGPSLat = system.getSource ({name="GPS", options=OPTION_LATITUDE})
    srcGPSLon = system.getSource ({name="GPS", options=OPTION_LONGITUDE})
end

-- Function to fetch sensor data
--  @return  pktStatus: packet status "N", "E", "C"
--  @return  lat: latitude or nil if error
--  @return  lon: longitude or nil if error
local function fetchTelemetry()
    -- Sensor found?
    -- if not srcSats or not srcGPSLat or not srcGPSLon then
    if not srcGPSLat or not srcGPSLon then
        discoverSensors()
        if not srcGPSLat or not srcGPSLon then
            return "N"  -- 'No sensor'
        end
    end

    -- Sensor available. Attempt to fetch GPS packet
    local lat = srcGPSLat:value()
    local lon = srcGPSLon:value()

    if not lat or not lon then
        lat = nil -- force both to nil
        lon = nil
        return "E"  -- 'Error' (GPS data not available or invalid)
    end

    -- good data found
    return "C", lat, lon
end

-- Poll GPS telemetry. This is called from the wakeup function.
-- @return  lat, lon if successful, else nil, nil
local function pollGPSTelemetry()

    -- Capture GPS data
    lastPktStatus, lastLat, lastLon = fetchTelemetry()

    -- Write entry to the log
    logging.write (
                math.floor (os.clock() * 1000),  -- mS
                lastLat and string.format (fmtLatLon, lastLat) or nil,
                lastLon and string.format (fmtLatLon, lastLon) or nil,
                srcSats and srcSats:value() or nil,
                lastPktStatus
            )

    return lastLat, lastLon
end

-- Poll in Demo mode
-- Ail stick moves sensor 
-- Ele stick simulates error condition
-- BearingOut should be set to 300° (via UI)
local function pollGPSTelemDemoMode()
    local t = os.clock() -- timestamp for log

    -- simulate error with forward elevator
    local v = system.getSource ({category=CATEGORY_ANALOG, member=ANALOG_STICK_ELEVATOR}):value()
    if v > 512 then
        lastPktStatus = "E"
        logging.write (t, nil, nil, nil, lastPktStatus)
        lastLat = nil
        lastLon = nil
    else
        -- simulate lat/lon with aileron
        -- Home position is 51.5074, -0.1278
        -- RH end point is 60m from home at 28°
        -- LH end point is 60m from home at 215°
        local latR, lonR = 51.507955837693, -0.12732516435117 -- right aileron
        local latL, lonL = 51.506884323208, -0.12838013000339 -- left aileron
        v = system.getSource ({category=CATEGORY_ANALOG, member=ANALOG_STICK_AILERON}):value()
        lastLat = ((v + 1024) * latR + (1024 - v) * latL) / 2048
        lastLon = ((v + 1024) * lonR + (1024 - v) * lonL) / 2048
        lastPktStatus = "C"
        logging.write (t, lastLat, lastLon, nil, lastPktStatus)
    end
    return lastLat, lastLon
end

-- assign polling function
sensor.poll = main.isDemoMode and pollGPSTelemDemoMode or pollGPSTelemetry

-- callbacks for form module
function sensor.getNumberOfSats()   return srcSats and srcSats:value() or nil end
function sensor.getLastPosition()   return lastLat, lastLon end
function sensor.getPktStatus()      return lastPktStatus end

return sensor
