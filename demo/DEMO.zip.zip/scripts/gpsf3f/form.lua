-- GPS virtual course for F3F script for Ethos
-- https://rc-soar.com/ethos/scripts/gpsf3f/
-- Copyright (c) Michael Shellim 2025 all rights reserved.

-- module for displaying configuration options (stored in widget) and telemetry data. 

local interval, config, sensor, course, f3f, logging = ... -- module handles passed via loadScript
local form = {} -- this module's table

-- Form field definitions. wgtOptionIdx refers to data stored in widget fields
local fields = {
    { wgtOptionIdx = 1},
    { wgtOptionIdx = 2},
    { wgtOptionIdx = 3},
    { wgtOptionIdx = 4},
    { wgtOptionIdx = 5},
    { wgtOptionIdx = 6},
--  { caption = "Logging",      fGet = logging.isActive, lookup = { [0] = "off", [1] = "on" } },
    { caption = "Sats",         fGet = sensor.getNumberOfSats },
    { caption = "F3F time",     fGet = f3f.getLastRunTime,  suffix = ' s' },
 -- { caption = "X, Y",         fGet = course.getLastPos,   suffix = ' m' },
    { caption = "X dist",       fGet = course.getLastX, suffix = ' m' },
    { caption = "Y dist",       fGet = course.getLastY, suffix = ' m' },
    { caption = "Poll rate",    fGet = interval.getFrequency, suffix=' Hz' },
    { caption = "Pkt status",   fGet = sensor.getPktStatus },
 -- { caption = "Mem remaining",fGet = function () return math.floor(collectgarbage("count")) end, suffix = ' kB' },
 -- { caption = "Avail stack",  fGet = function () return system.getMemoryUsage().mainStackAvailable end, suffix = ' B' },
 -- { caption = "Avail RAM",  fGet = function () return system.getMemoryUsage().ramAvailable end, suffix = ' B' },
 -- { caption = "Avail LuaRAM",  fGet = function () return system.getMemoryUsage().luaRamAvailable end, suffix = ' B' },
}

local fontSize = FONT_STD -- FONT_STD, FONT_BOLD, FONT_ITALIC, FONT_XS, FONT_XS_BOLD, FONT_S, FONT_L, FONT_L_BOLD, FONT_XL, FONT_XXL
local fontHt   -- font height
local valueWidth -- width to reserve for values, = 7 character widths

-- Initialise the form, setting its position and size
--  @param xOrigin: x coordinate of the form's top left corner
--  @param yOrigin: y coordinate of the form's top left corner
--  @param width: width of form
--  @return height: height of form
function form.init (xOrigin, yOrigin, width)

    -- select a font
    lcd.font (fontSize)
    valueWidth, fontHt = lcd.getTextSize ("abcdefg")

    local lineSpacing = 1
    local nCols = 3 

    -- initialise display variables
    local dy = fontHt + lineSpacing                 -- row pitch
    local dx = math.ceil (width / nCols)            -- column pitch
    local hForm = math.ceil (#fields/nCols) * dy    -- height of form
    local yMax = yOrigin + hForm                    -- max y position for fields

    -- Allocate coordinates to each field, by rows then col.
    local x = xOrigin + dx - valueWidth
    local y = yOrigin
    for _, f in ipairs (fields)  do
        -- store the position
        f.x = x
        f.y = y

        -- advance to next position, start new column if overflow.
        y = y + dy
        if y >= yMax then
            y = yOrigin
            x = x + dx
        end
    end
    return (hForm) -- return height of formatted form
end

-- Given a local field definition, gets the caption and value
--  @param f: field definition
--  @return caption: caption
--  @return val: string value
local function getNonWidgetItem (f)
    local v = f.fGet()
    if v == nil then 
        v = '---'
    elseif f.lookup then
        v = f.lookup [v]
    elseif f.suffix then 
        v = v .. f.suffix
    end
    return f.caption, v
end

-- Paints the form
--  @param widget 
function form.show (widget)

    -- display the form
    lcd.font (fontSize)
    for _, f in ipairs (fields)  do
        -- get the caption and value to display
        local val
        local caption
        if f.wgtOptionIdx then
            -- get info from widget
            caption, val = config.getItem (widget, f.wgtOptionIdx)
        else
            -- get info from local field
            caption, val = getNonWidgetItem (f)
        end
        -- display the value
        lcd.drawText (f.x, f.y, caption .. ': ', RIGHT)
        lcd.drawText (f.x, f.y, val, LEFT)
    end
end

return form

