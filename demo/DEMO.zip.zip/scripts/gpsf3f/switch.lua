-- GPS virtual course for F3F script for Ethos
-- https://rc-soar.com/ethos/scripts/gpsf3f/
-- Copyright (c) Michael Shellim 2025 all rights reserved.

-- Switch class
-- This class is used to detect state transitions of a virtual switch.
local switch = {}

switch.PRESSED = true
switch.RELEASED = false

--[[ 
Constructor for switch class
    Usage: sw = switch:new ()
--]]
function switch.new(self, metaName)
    local o = {}
    setmetatable(o, self)
    self.__index = self
    o.metaName = metaName
    o.lastState = true
    return o
end

-- Detect change of switch state.
-- @return switch state true/false if changed else nil
function switch.event(self, widget)
    local source = widget [self.metaName]
    if source == nil then return end
    local state = source:value() > 0 -- Get the current state of the switch
    if state ~= self.lastState then
        self.lastState = state
        return state
    end
end

function switch.defined(self, widget)
    return widget [self.metaName]:category() ~= CATEGORY_NONE
end

return switch
