-- GPS virtual course for F3F script for Ethos
-- https://rc-soar.com/ethos/scripts/gpsf3f/
-- Copyright (c) Michael Shellim 2025 all rights reserved.

-- Handles display of status line
local status = {}
local font = FONT_STD    -- font for status text
local hStatus           -- height of status text
local x0, y0, w, h      -- bounding rectangle
local version

-- state variables
local currString = "" 

-- intialise the status line.
-- returns the height of the status line
function status.init(...)
    x0, y0, w, h, version = ...

    -- Set line height
    lcd.font (font)
    _, hStatus = lcd.getTextSize ("X")
    hStatus = hStatus + 1   -- add 1 pixel for line spacing

    -- currString = ""
    -- currPriority = status.LOW_PRIORITY
    return hStatus  -- return the height of the status line
end

-- Display status string and script version.
function status.show()
    lcd.font (font)
    local y = y0 + h - hStatus
    lcd.drawText(x0,        y, currString)
    lcd.drawText(x0 + w,    y, "v" .. version, RIGHT)
end

-- Reset the status line. Call this at the start of the background loop.
function status.reset()
    currString = ""
end

-- set the status string to be displayed. 
function status.setStatus(newString)
    currString = newString
end

return status
