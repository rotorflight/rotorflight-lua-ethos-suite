-- GPS virtual course for F3F script for Ethos.
-- https://rc-soar.com/ethos/scripts/gpsf3f/
-- Copyright (c) Michael Shellim 2025 all rights reserved.

-- module for managing course configuration
local config={}

-- exposed constants
config.LEFT   = 0 -- base A
config.RIGHT  = 1
config.START_SWITCH = "swStartAbort" -- widget field names
config.HOME_SWITCH  = "swSetHome"

-- widget metadata, each entry corresponds to a widget field
local wgtMetaData = {
  {name = "bearingOut", caption = "Bearing out", type = "number", default = 0, min = 0, max = 360, step = 5, suffix = "°", help = "Enter the bearing on the sighting point on the horizon."},
  {name = "courseLen",  caption = "Course len",  type = "number", default = 100, min = 10, max = 100, step = 10, suffix = " m", help = "Enter the length of the course in metres."},
  {name = "sideBaseA",  caption = "Base A",      type = "choice", default = config.LEFT, choices = { {"Left", config.LEFT}, {"Right", config.RIGHT} }, lookup = { [config.LEFT] = "Left", [config.RIGHT] = "Right" }},
  {name = "maxLegs",    caption = "Max legs",    type = "number", default = 10, min = 1, max = 20, step = 1, help = "Enter the maximum number of legs to fly."},
  {name = config.HOME_SWITCH ,  caption = "Center sw", type = "switch", default = CATEGORY_NONE},
  {name = config.START_SWITCH,  caption = "Start  sw",type = "switch", default = CATEGORY_NONE},
}

-- Called in create() to create widget table.
-- Sets default values 
-- Note: the values are overwritten by config.read() in second and subsequent activations.
-- @return widget table 
function config.Init ()
  local widget = {}
  for _, m in pairs (wgtMetaData) do
    if m.type == "switch" then
      widget[m.name] = system.getSource (m.default)
    else
      widget[m.name] = m.default
    end
  end
  return widget
end

-- read configuration values from file store
-- @param widget 
function config.read (widget)
    local val
    for _, m in ipairs (wgtMetaData) do
        val = storage.read (m.name)
        if val then widget[m.name] = val end
    end
end


-- write configuration to file store
-- @param widget
function config.write (widget)
    for _, m in ipairs (wgtMetaData) do
        storage.write (m.name, widget[m.name])
    end
end

-- configuration screen
-- @param widget
function config.configure (widget)
  local line
  local field

  -- Display the form
  for _, m in ipairs (wgtMetaData) do
    if m.type == "number" then
        line = form.addLine(m.caption)
        field = form.addNumberField (line, nil, m.min, m.max,
          function() return widget[m.name] end,
          function(newValue) widget[m.name]=newValue end
          )

    elseif m.type == "choice" then
      line = form.addLine(m.caption)
      form.addChoiceField(line, nil, m.choices,
        function() return widget[m.name] end,
        function(newValue) widget[m.name] = newValue end
        )

    elseif m.type == "switch" then
      line = form.addLine(m.caption)
      field = form.addSwitchField(line, nil,
        function() return widget[m.name] end,
        function(newValue) widget[m.name] = newValue end
        )
    end

    if m.step then field:step(m.step) end
    if m.suffix then field:suffix(m.suffix) end
    if m.help then field:help(m.help) end
  end
end

-- Get the caption and string value of a widget field
-- In the case of a switch, the value is the name of the switch
--  @param widget
--  @param index in metadata table
--  @return caption: caption
--  @return strval: string value
function config.getItem (widget, mIndex)
  local m = wgtMetaData[mIndex]
  local val = widget[m.name]
  local strVal
  if m.type == "switch" then
      strVal = val and val:name() or '---'  -- raw value is switch source, we want the name
  else
      if val == nil then
        strVal = '---'
      elseif m.lookup then 
        strVal = m.lookup [val]
      elseif m.suffix then
        strVal = val .. m.suffix
      else
        strVal = tostring(val)
      end
  end
  return m.caption, strVal
end

return config